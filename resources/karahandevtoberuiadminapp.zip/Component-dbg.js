sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("karahan.devtober.ui.adminapp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);